﻿using Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Logica.Library
{
    public class Librarys : Conexion
    {
        public Uploadimage uploadimage = new Uploadimage();
        public TextBoxEvent textBoxEvent = new TextBoxEvent();
    }
}
